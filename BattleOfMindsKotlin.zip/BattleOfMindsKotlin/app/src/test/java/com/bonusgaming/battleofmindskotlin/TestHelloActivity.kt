package com.bonusgaming.battleofmindskotlin

import org.junit.Test

import org.junit.Assert.*
import org.junit.Rule
import org.mockito.junit.MockitoJUnit
import org.mockito.junit.MockitoRule



class TestHelloActivity {
    @Rule
    var rule = MockitoJUnit.rule()




}
