package com.bonusgaming.battleofmindskotlin

 enum class FragmentState {
    LOGO, MAIN, LOADING, GAME, RESULT, STATISTICS, SETTINGS,AVATAR
}