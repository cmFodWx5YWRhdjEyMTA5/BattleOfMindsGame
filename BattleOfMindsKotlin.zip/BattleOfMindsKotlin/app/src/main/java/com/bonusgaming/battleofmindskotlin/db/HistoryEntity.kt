package com.bonusgaming.battleofmindskotlin.db

import androidx.room.Entity

const val tableName = "history"

@Entity(tableName = tableName)
class HistoryEntity() : BaseEntity() {

}